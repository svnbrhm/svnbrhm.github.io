import { GetStaticProps } from 'next'
import Head from 'next/head'
import { Suspense } from 'react'
import Header from '../components/Header'
import HeroSection from '../components/HeroSection'
import StatsSection from '../components/StatsSection'
import InteractiveMap from '../components/InteractiveMap'
import CrewGallery from '../components/CrewGallery'
import BlogPreview from '../components/BlogPreview'
import EventsList from '../components/EventsList'
import RoutesList from '../components/RoutesList'

interface HomePageProps {
  crews: any[]
  blogPosts: any[]
  events: any[]
  routes: any[]
  stats: any
}

export default function HomePage({ crews, blogPosts, events, routes, stats }: HomePageProps) {
  return (
    <>
      <Head>
        <title>RunningCrews - Global Running Community</title>
        <meta name="description" content="Connect with running communities worldwide and discover your next adventure" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;900&family=Lato:wght@300;400;700&display=swap" rel="stylesheet" />
      </Head>

      {/* �0�4 TEST - Das sollte sichtbar sein! */}
      <div style={{
        position: 'fixed',
        top: 0,
        right: 0,
        background: 'red',
        color: 'white',
        padding: '10px',
        zIndex: 9999,
        fontSize: '12px'
      }}>
        �7�3 NEUE SEITE L�0�2DT!
      </div>

      {/* Header */}
      <Header />

      <main className="min-h-screen">
        {/* Hero Section */}
        <HeroSection />
        
        {/* Stats Section */}
        <StatsSection />
        
        {/* Interactive World Map */}
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-black text-gray-900 mb-4">
                Discover Crews <span className="text-orange-500">Worldwide</span>
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Explore running communities across the globe and find your perfect crew
              </p>
            </div>
            <Suspense fallback={
              <div className="w-full h-96 bg-gray-200 rounded-2xl flex items-center justify-center">
                <div className="text-gray-500">Loading map...</div>
              </div>
            }>
              <InteractiveMap crews={crews} />
            </Suspense>
          </div>
        </section>

        {/* Featured Crews Gallery */}
        <section className="py-20 bg-white" id="crews">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-black text-gray-900 mb-4">
                Featured <span className="text-orange-500">Running Crews</span>
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Meet the most active and inspiring running communities
              </p>
            </div>
            <CrewGallery crews={crews} />
            <div className="text-center mt-12">
              <a 
                href="/crews" 
                className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-8 py-4 rounded-full text-lg font-semibold hover:shadow-2xl hover:scale-105 transition-all duration-300"
              >
                Explore All Crews
              </a>
            </div>
          </div>
        </section>

        {/* Blog Preview */}
        <section className="py-20 bg-gray-50" id="blog">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-black text-gray-900 mb-4">
                Community <span className="text-orange-500">Stories</span>
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Read inspiring stories from runners around the world
              </p>
            </div>
            <BlogPreview posts={blogPosts} />
            <div className="text-center mt-12">
              <a 
                href="/blog" 
                className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-8 py-4 rounded-full text-lg font-semibold hover:shadow-2xl hover:scale-105 transition-all duration-300"
              >
                See All Stories
              </a>
            </div>
          </div>
        </section>

        {/* Upcoming Events */}
        <section className="py-20 bg-white" id="events">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-black text-gray-900 mb-4">
                Upcoming <span className="text-orange-500">Events</span>
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Join exciting running events and meet fellow runners
              </p>
            </div>
            <EventsList events={events} />
            <div className="text-center mt-12">
              <a 
                href="/events" 
                className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-8 py-4 rounded-full text-lg font-semibold hover:shadow-2xl hover:scale-105 transition-all duration-300"
              >
                Explore All Events
              </a>
            </div>
          </div>
        </section>

        {/* Running Routes */}
        <section className="py-20 bg-gray-50" id="routes">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-black text-gray-900 mb-4">
                Discover <span className="text-green-500">Running Routes</span>
              </h2>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Explore amazing running routes from cities around the world
              </p>
            </div>
            <RoutesList routes={routes} />
            <div className="text-center mt-12">
              <a 
                href="/routes" 
                className="bg-gradient-to-r from-green-500 to-green-600 text-white px-8 py-4 rounded-full text-lg font-semibold hover:shadow-2xl hover:scale-105 transition-all duration-300"
              >
                View All Routes
              </a>
            </div>
          </div>
        </section>
      </main>
    </>
  )
}

export const getStaticProps: GetStaticProps = async () => {
  return {
    props: {
      crews: [],
      blogPosts: [],
      events: [],
      routes: [],
      stats: {},
    },
  }
}